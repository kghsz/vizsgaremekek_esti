-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Máj 07. 18:57
-- Kiszolgáló verziója: 10.4.27-MariaDB
-- PHP verzió: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `blackbunny3`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kategóriák`
--

CREATE TABLE `kategóriák` (
  `Kategória ID` int(100) NOT NULL,
  `Név` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `kategóriák`
--

INSERT INTO `kategóriák` (`Kategória ID`, `Név`) VALUES
(1, 'Egyedi feliratos táblás csokoládé\r\n'),
(2, 'Magvas táblás csokoládé (mandula, tökmag, földimogyoró, török mogyoró, pisztácia)\r\n'),
(3, 'Liofilizált gyümölcsös csokoládé (málna, eper, őszibarack, narancs)\n'),
(4, 'Egyedi díszített táblás csokoládé\r\n'),
(5, 'Bonbon 5 db-os\r\n'),
(6, 'Bonbon 14 db-os\r\n'),
(7, 'Csokinyalóka ostya díszítéssel\r\n'),
(8, 'Szezonális, ünnepi tematikájú egyedi formás csokoládé figurák 15g-tól\n'),
(9, 'Dobozos marcipános tallér \r\n');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kosar`
--

CREATE TABLE `kosar` (
  `kosar_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `termek_id` int(11) NOT NULL,
  `mennyiseg` int(11) NOT NULL DEFAULT 1,
  `datum` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `kosar`
--

INSERT INTO `kosar` (`kosar_id`, `user_id`, `termek_id`, `mennyiseg`, `datum`) VALUES
(28, 111112, 41001022, 2, '2024-05-07 18:33:59'),
(29, 111112, 54003004, 1, '2024-05-07 18:34:01'),
(31, 111112, 54003005, 1, '2024-05-07 18:34:04'),
(32, 111119, 41001121, 1, '2024-05-07 18:34:27'),
(33, 111119, 41001221, 1, '2024-05-07 18:34:30'),
(34, 111119, 54003409, 1, '2024-05-07 18:34:32'),
(35, 111116, 85001304, 1, '2024-05-07 18:34:48'),
(36, 111116, 91005103, 2, '2024-05-07 18:34:50');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `rendelések`
--

CREATE TABLE `rendelések` (
  `Rendelés ID` int(100) NOT NULL,
  `Vásárló ID` int(100) NOT NULL,
  `Megrendelés dátuma` date NOT NULL,
  `Állapot` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `rendelések`
--

INSERT INTO `rendelések` (`Rendelés ID`, `Vásárló ID`, `Megrendelés dátuma`, `Állapot`) VALUES
(123456, 111111, '2024-01-15', 'Lezárt'),
(123457, 111112, '2024-02-01', 'Lezárt'),
(123458, 111113, '2024-03-02', 'Nyitott'),
(123459, 111114, '2024-03-06', 'Lezárt'),
(123460, 111115, '2024-03-08', 'Lezárt'),
(123461, 111116, '2024-03-16', 'Lezárt'),
(123462, 111117, '2024-03-18', 'Lezárt'),
(123463, 111118, '2024-03-18', 'Lezárt'),
(123464, 111119, '2024-03-19', 'Lezárt'),
(123465, 111120, '2024-03-19', 'Nyitott');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `termekek`
--

CREATE TABLE `termekek` (
  `termek_id` int(100) NOT NULL,
  `nev` varchar(100) NOT NULL,
  `egysegar` int(100) NOT NULL,
  `leiras` varchar(100) NOT NULL,
  `keszlet` int(100) NOT NULL,
  `kiszereles` varchar(100) NOT NULL,
  `kategoria_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `termekek`
--

INSERT INTO `termekek` (`termek_id`, `nev`, `egysegar`, `leiras`, `keszlet`, `kiszereles`, `kategoria_id`) VALUES
(41001021, 'Étcsokoládé\r\n', 1950, 'cukros', 50, '90g', 9),
(41001022, 'Étcsokoládé\r\n', 1950, 'cukormentes', 60, '90g', 9),
(41001121, 'Tejcsokoládé\r\n\r\n', 1950, 'cukros', 50, '90g', 9),
(41001122, 'Tejcsokoládé\r\n\r\n', 1950, 'cukormentes', 50, '90g', 9),
(41001221, 'Fehér csokoládé\r\n\r\n\r\n', 1950, 'cukros', 50, '90g', 9),
(41001222, 'Fehér csokoládé\r\n\r\n\r\n', 1950, 'cukormentes', 50, '90g', 9),
(54003004, 'Étcsokoládé\r\n', 500, 'cukros', 10, '15g', 8),
(54003005, 'Étcsokoládé\r\n', 500, 'cukormentes', 36, '15g', 8),
(54003006, 'Étcsokoládé\r\n', 1000, 'cukros', 25, '30g', 8),
(54003007, 'Étcsokoládé\r\n', 1000, 'cukormentes', 26, '30g', 8),
(54003008, 'Étcsokoládé\r\n', 1500, 'cukros', 50, '45g', 8),
(54003009, 'Étcsokoládé\r\n', 1500, 'cukormentes', 60, '45g', 8),
(54003104, 'Tejcsokoládé\r\n', 1000, 'cukros', 25, '30g', 8),
(54003105, 'Tejcsokoládé\r\n', 1000, 'cukormentes', 36, '30g', 8),
(54003106, 'Tejcsokoládé\r\n', 1500, 'cukros', 20, '45g', 8),
(54003107, 'Tejcsokoládé\r\n', 1500, 'cukormentes', 36, '45g', 8),
(54003204, 'Fehér csokoládé\r\n', 500, 'cukros', 20, '15g', 8),
(54003205, 'Fehér csokoládé\r\n', 500, 'cukormentes', 50, '15g', 8),
(54003206, 'Fehér csokoládé\r\n', 1000, 'cukros', 25, '30g', 8),
(54003207, 'Fehér csokoládé\r\n', 1000, 'cukormentes', 50, '30g', 8),
(54003208, 'Fehér csokoládé\r\n', 1500, 'cukros', 100, '45g', 8),
(54003209, 'Fehér csokoládé\r\n', 1500, 'cukormentes', 15, '45g', 8),
(54003304, 'Epres -fehércsokoládé\r\n', 500, 'cukros', 50, '15g', 8),
(54003305, 'Epres -fehércsokoládé\r\n', 500, 'cukormentes', 35, '15g', 8),
(54003306, 'Epres -fehércsokoládé\r\n', 1000, 'cukros', 35, '30g', 8),
(54003307, 'Epres -fehércsokoládé\r\n', 1000, 'cukormentes', 60, '30g', 8),
(54003308, 'Epres -fehércsokoládé\r\n', 1500, 'cukros', 50, '45g', 8),
(54003309, 'Epres -fehércsokoládé\r\n', 1500, 'cukormentes', 50, '45g', 8),
(54003310, 'Epres -fehércsokoládé\r\n', 2000, 'Gluténmentes,tejementes\r\n', 60, '15g', 8),
(54003404, 'Karamellás\r\n', 500, 'cukros', 25, '15g', 8),
(54003405, 'Karamellás\r\n', 500, 'cukormentes', 60, '15g\r\n', 8),
(54003406, 'Karamellás\r\n', 1000, 'cukros', 20, '30g', 8),
(54003407, 'Karamellás\r\n', 1000, 'cukormentes', 36, '30g', 8),
(54003408, 'Karamellás\r\n', 1500, 'cukros', 35, '45g', 8),
(54003409, 'Karamellás\r\n', 1500, 'cukormentes', 50, '45g', 8),
(63004002, 'Karamellás csokoládé\r\n', 950, 'cukros', 20, '25g', 7),
(63004003, 'Karamellás csokoládé\r\n', 950, 'cukormentes', 50, '25g\r\n', 7),
(63004102, 'Epres-fehércsokoládé\r\n', 950, 'cukros', 20, '25g\r\n', 7),
(63004103, 'Epres-fehércsokoládé\r\n', 950, 'cukormentes', 60, '25g\r\n', 7),
(71002006, 'Étcsokoládé\r\n', 1900, 'cukros', 10, '60g\r\n', 4),
(71002007, 'Étcsokoládé\r\n', 1900, 'cukormentes', 36, '60g\r\n', 4),
(71002106, 'Tejcsokoládé\r\n', 1900, 'cukros', 20, '60g\r\n', 4),
(71002107, 'Tejcsokoládé\r\n', 1900, 'cukormentes', 50, '60g\r\n', 4),
(71002206, 'Fehér csokoládé\r\n', 1900, 'cukros', 50, '60g\r\n', 4),
(71002207, 'Fehér csokoládé\r\n', 1900, 'cukormentes', 36, '60g\r\n', 4),
(85001003, 'Málnás-fehér csokoládé\r\n', 1950, 'cukros', 15, '5 db', 5),
(85001004, 'Málnás-fehér csokoládé\r\n', 1950, 'cukormentes', 50, '5 db', 5),
(85001103, 'Karamellás- étcsokoládés\r\n', 1950, 'cukros', 10, '5 db', 5),
(85001104, 'Karamellás- étcsokoládés\r\n', 1950, 'cukormentes', 60, '5 db', 5),
(85001203, 'Étcsokoládés -földimogyorós\r\n', 1950, 'cukros', 20, '5 db', 5),
(85001204, 'Étcsokoládés -földimogyorós\r\n', 1950, 'cukormentes', 60, '5 db', 5),
(85001303, 'Málnás-fehér csokoládé\r\n', 3950, 'cukros', 50, '110g\r\n', 6),
(85001304, 'Málnás-fehér csokoládé\r\n', 3950, 'cukormentes', 60, '110g\r\n', 6),
(85001403, 'Karamellás- étcsokoládés\r\n', 3950, 'cukros', 10, '110g\r\n', 6),
(85001404, 'Karamellás- étcsokoládés\r\n', 3950, 'cukormentes', 50, '110g\r\n', 6),
(85001503, 'Étcsokoládés -földimogyorós\r\n', 3950, 'cukros', 50, '110g\r\n', 6),
(85001504, 'Étcsokoládés -földimogyorós\r\n', 3950, 'cukormentes', 60, '110g\r\n', 6),
(91005001, 'Étcsokoládé', 3300, 'cukros', 10, '100g', 1),
(91005002, 'Étcsokoládé', 3300, 'cukormentes', 20, '100g', 1),
(91005101, 'Tejcsokoládé', 3300, 'cukros', 50, '100g', 1),
(91005102, 'Tejcsokoládé', 3300, 'cukormentes', 12, '100g', 1),
(91005103, 'Tejcsokoládé', 3300, 'cukormentes', 25, '100g', 1),
(91005201, 'Fehér csokoládé', 3300, 'cukros', 25, '100g', 1),
(91005202, 'Fehér csokoládé\r\n', 3300, 'cukormentes', 35, '100g', 1),
(91005301, 'Epres- fehér csokoládé (liofilizált eper darabok)\r\n', 3300, 'cukros', 52, '100g', 1),
(91005302, 'Epres- fehér csokoládé (liofilizált eper darabok)\r\n', 3300, 'cukormentes', 50, '100g\r\n', 1),
(91005401, 'Tökmagos-fehér csokoládé (darált tökmag)\r\n', 3300, 'cukros', 60, '100g\r\n', 1),
(91005402, 'Tökmagos-fehér csokoládé (darált tökmag)\r\n', 3300, 'cukormentes', 50, '100g\r\n', 1),
(91005501, 'Narancsos- fehér csokoládé \r\n', 3300, 'cukros', 45, '100g\r\n', 1),
(91005502, 'Narancsos- fehér csokoládé \r\n', 3300, 'cukormentes', 54, '100g\r\n', 1),
(91014001, 'Étcsokoládé\r\n', 2500, 'cukros', 100, '100g\r\n', 2),
(91014002, 'Étcsokoládé\r\n', 2500, 'cukormentes', 50, '100g', 2),
(91014101, 'Tejcsokoládé\r\n', 2500, 'cukros', 15, '100g\r\n', 2),
(91014102, 'Tejcsokoládé\r\n', 2500, 'cukormentes', 60, '100g', 2),
(91014201, 'Fehér csokoládé\r\n', 2500, 'cukros', 35, '100g\r\n', 2),
(91014202, 'Fehér csokoládé\r\n', 2500, 'cukormentes', 36, '100g\r\n\r\n', 2),
(91035001, 'Étcsokoládé\r\n', 2500, 'cukros', 38, '100g\r\n', 3),
(91035002, 'Étcsokoládé\r\n', 2500, 'cukormentes', 50, '100g\r\n', 3),
(91035101, 'Tejcsokoládé\r\n', 2500, 'cukros', 10, '100g\r\n', 3),
(91035102, 'Tejcsokoládé\r\n', 2500, 'cukormentes', 50, '100g\r\n', 3),
(91035201, 'Fehér csokoládé\r\n', 2500, 'cukros', 25, '100g\r\n', 3),
(91035202, 'Fehér csokoládé\r\n', 2500, 'cukormentes', 50, '100g\r\n', 3);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `user_id` int(100) NOT NULL,
  `fnev` varchar(255) NOT NULL,
  `vnev` varchar(100) NOT NULL,
  `knev` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jelszo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`user_id`, `fnev`, `vnev`, `knev`, `email`, `jelszo`) VALUES
(1, 'csdav', 'Csendes', 'Dávid', 'csendes.dvid@gmail.com', '$2y$10$JfJDHSs8vKGL8stPL.dYN.Ng0imdub2mXqdkQVMbbzBK.26oRqr0u'),
(111111, 'krich', 'Kiss', 'Richárd', 'rihardkiss15@gmail.com', '$2y$10$FI45oNIwErZ.KH4VTcocPeyaCjQM83xPXv6KPFIX6Bufzmm3qzfTG'),
(111112, 'kalmi23', 'Szabó', 'Kálmán', 'dzabo254@gmail.com', '$2y$10$yy0vKlh53fgL357Up1gsoemv9GKSA3oUnKRQRzjBqv.RTcMPdxyKq'),
(111113, 'roberto1', 'Kalota', 'Ádám Róbert', 'veddmeg@freemail.hu', '$2y$10$FPCUgujmmQ2KYEhQ3iUURu5NqWPBFrPYBBPKzPbHwC6LjeZ5tiHY2'),
(111114, 'julcsisz', 'Szendi', 'Júlia', 'szendereg@citromail.com', '$2y$10$2/vaN2qHfPjvYN5yz5d4i.VlcTXxkgaf8bocz9.BpHJADIfT1IK1a'),
(111115, 'ljanosne1976', 'Ludman', 'Jánosné', 'ludman25@gmail.com', '$2y$10$OEt0MrlJHdrvOgPyNgh2su57tipo3MqooPITtCf2gvdM7ncRHVIva'),
(111116, 'szda73', 'Szurmai', 'Dániel', 'szurmai@freemail.hu', '$2y$10$rEB/71h7B8L1v/kKAGtYluOCna9K9fKoLDtqG/uYQdEDk8PVn7yWm'),
(111117, 'marika14', 'Hüse', 'Zoltánné', 'husene@citromail.com', '$2y$10$Bjt/kRiZ1vaLb8mpW7PKL.yimfFMd9nebDxP4E/.U6NmcOAJATD72'),
(111118, 'margareta', 'Kapás', 'Margit', 'margareta@freemail.hu', '$2y$10$1p870KgaObRZGI0eJPBt0uV641beeibx/TCrgr5dGzSUoedjCqBDC'),
(111119, 'kupakati', 'Kupai', 'Katalin', 'kupa@gmail.com', '$2y$10$5pGrF8SOPSMxuqojQSECXOelNZwqFuJWTGj7C9SwSle/8X0fY1DQm'),
(111120, 'nagybanderas', 'Nagy', 'András', 'nagynagy@freemail.hu', '$2y$10$lokLmgslJ2XB.dqQLVbtKu2JB0/ghqHSp13YyV3QZ/VXVUJppOzpq');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `kategóriák`
--
ALTER TABLE `kategóriák`
  ADD PRIMARY KEY (`Kategória ID`);

--
-- A tábla indexei `kosar`
--
ALTER TABLE `kosar`
  ADD PRIMARY KEY (`kosar_id`),
  ADD UNIQUE KEY `unique_kosar` (`termek_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- A tábla indexei `rendelések`
--
ALTER TABLE `rendelések`
  ADD PRIMARY KEY (`Rendelés ID`);

--
-- A tábla indexei `termekek`
--
ALTER TABLE `termekek`
  ADD PRIMARY KEY (`termek_id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `kosar`
--
ALTER TABLE `kosar`
  MODIFY `kosar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111132;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `kosar`
--
ALTER TABLE `kosar`
  ADD CONSTRAINT `kosar_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `kosar_ibfk_2` FOREIGN KEY (`termek_id`) REFERENCES `termekek` (`termek_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
