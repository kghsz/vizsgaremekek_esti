<?php
include "kozos.php";

    
        
    


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fnev = mysqli_real_escape_string($kapcsolat, $_POST["fnev"]);
        $vnev = mysqli_real_escape_string($kapcsolat, $_POST["vnev"]);
        $email = mysqli_real_escape_string($kapcsolat, $_POST["email"]);
        $sz_hely= mysqli_real_escape_string($kapcsolat,$_POST["sz_hely"]);
        $sz_ido= mysqli_real_escape_string($kapcsolat,$_POST["sz_ido"]);
        $jelszo = mysqli_real_escape_string($kapcsolat, $_POST["jelszo"]);
        $jelszo2 = mysqli_real_escape_string($kapcsolat, $_POST["jelszo2"]);
        $hashelt_jelszo = jelszo_hash($jelszo);

    

    
    $kapcsolat = mysqli_connect("localhost", "root", "",$db_nev);

    // Kpacsolta ellenőrzés
    if ($kapcsolat === false) {
        die("Kapcsolódási hiba: " . mysqli_connect_error());
    }

    $sql = "INSERT INTO felhasznalok (f_nev, nev, email, sz_hely, szul_ido, jelszo) 
            VALUES ('$fnev', '$vnev', '$email', '$sz_hely', '$sz_ido', '$hashelt_jelszo')";

    // Új rekord hozzáadásának ellenőrzése
    if ($kapcsolat->query($sql) === TRUE) {
        echo "Sikeres regisztráció!";
    } else {
        echo "A rekord hozzáadása az adatbázisba nem sikerült: " . $kapcsolat->error;
    }

    // Kapcsolat lezárása
    $kapcsolat->close();
    
    // Kapcsolódás az "onyx" adatbázishoz
    $kapcsolat = mysqli_connect("localhost", "root", "", "onyx");

    // kapcsolat ellenőrzés az "onyx" adatbázishoz
    if ($kapcsolat === false) {
        die("Kapcsolódási hiba az onyx adatbázishoz: " . mysqli_connect_error());
    }

  

    $sql = "INSERT INTO felhasznalok (f_nev, jelszo, db_nev) 
            VALUES ('$fnev', '$hashelt_jelszo', '$db_nev')";

    // Új rekord hozzáadásának ellenőrzése az "onyx" adatbázisban
    if ($kapcsolat->query($sql) === TRUE) {
        
    } else {
        echo "A rekord hozzáadása az onyx adatbázisba nem sikerült: " . $kapcsolat->error;
    }

    // Kapcsolat lezárása az "onyx" adatbázissal
    $kapcsolat->close();
}

?>

<h1>Dolgozó regisztrálása</h1>
<hr>
<form action="" method="post" enctype="multipart/form-data">
    <label for="vnev">Név:</label>
    <input type="text" name="vnev" id="vnev" required>
    <br>
    <label for="fnev">Felhasználó név:</label>
    <input type="text" name="fnev" id="fnev" required>
    <br>
    <label for="email">E-mail cím:</label>
    <input type="email" name="email" id="email" required>
    <br>
    <label for="sz_hely">Születési hely:</label>
    <input for="text" name="sz_hely" id="sz_hely" required>
    <br>
    <label for="sz_ido">Születési idő:</label>
    <input type="date" name="sz_ido" id="sz_ido" required>
    <br>
    <label for="pwd">Jelszó</label>
    <input type="password" name="jelszo" id="jelszo" required>
    <br>
    <label for="pwd2">Jelszó mégegyszer</label>
    <input type="password" name="jelszo2" id="jelszo2" required>
    <br>
    <input type="submit" class="dolgozoreg" name="submit" value="Regisztráció" >
</form>
