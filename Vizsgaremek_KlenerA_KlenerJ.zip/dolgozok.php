<head>
<script>
         $(document).ready(function(){
            $("#nevsor").empty(); //kitöröljüók a tarlamat
            szerver="rest.php";
            $.post(szerver, {dolgozo:0},function(resp){
                console.log(resp);
                n=resp.length;
                if(n>0)
                {
                    $select=$("#dolgozo");
                    for( i=0;i<n;i++)
                    {
                        dolgozo=resp[i].dolgozo;
                        $option=$("<option>").text(dolgozo).val(dolgozo);
                        $select.append($option);
                    }
                }
            })
        //post vége
        $("#keres").click(function(){
                $("#nevsor").empty();
                e=$("#dolgozo").val();         
                $.post(szerver, {ev:e}, function(resp){
                    console.log(resp);
                    n=resp.length;
                    tabla=$("<table>");
                    fejlec=$("<tr>");
                    fejlec.append("<th>Felhasználó azonosítója</th>");
                    fejlec.append("<th>Felhasználó név</th>");
                    fejlec.append("<th>Teljes név</th>");
                    fejlec.append("<th>Email</th>");
                    fejlec.append("<th>Születési hely</th>");
                    fejlec.append("<th>Születési idő</th>");
                    tabla.append(fejlec);
                    if(n>0)
                    {
                        
                        for( i=0;i<n;i++)
                        {
                            sor = $("<tr>");
                            sor.append("<td>" + resp[i].felh_id + "</td>");
                            sor.append("<td>" + resp[i].f_nev + "</td>");
                            sor.append("<td>" + resp[i].nev + "</td>");
                            sor.append("<td>" + resp[i].email + "</td>");
                            sor.append("<td>" + resp[i].sz_hely + "</td>");
                            sor.append("<td>" + resp[i].szul_ido + "</td>");
                            tabla.append(sor);
                            $("#nevsor").append(tabla);
                        }
                    }
                })
            })
        })
    </script>
</head>
<body>
    
    <div>
    <h1>Dolgozók</h1>
        <select id="dolgozo" ><!--ide jönnek a dolgozók--></select>
        <button id="keres">Keresés</button>
    <!--php fáj beilesztése-->
    </div>
    <div id="nevsor">
        
    </div>
    
    
    
</body>