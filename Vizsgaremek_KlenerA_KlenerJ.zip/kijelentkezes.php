<?php

// Töröljük a session változókat
session_unset();

// Megsemmisítjük a session-t
session_destroy();

// Átirányítás az 'index.php' oldalra
header("Location: index.php");
exit;
?>
