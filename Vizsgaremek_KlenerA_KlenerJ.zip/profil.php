<?php
session_start();
 // Ellenőrizd, hogy a session változók már léteznek-e
 if(isset($_SESSION['db_nev'])) {
    // Ha már vannak session változók, lekérjük azokat

    $db_nev = $_SESSION['db_nev'];

    // Most már használhatod ezeket az adatokat
    echo "A cég neve: $db_nev <br>";
    
} else {
    // Ha nincsenek session változók, valamilyen hiba történt
    echo "Hiba: Nincsenek elérhető session változók!";
}
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="design_profil.css">
    <title>Onyx Control Control</title>

</head>

<body>
    <header>
    <div class="fejlec">
            <div class="logodiv">
                    <img src="home_logo.JPG" id="logo">
                    <a href="cegprofil.php?aloldal=profil_start" id="logo_sz">Onyx Corporate Control</a> 
            </div>
            <nav id="menu">   <!--menü-->
                <ul id="foMenu">
                    <li><a href="profil.php?aloldal=beosztas" >Beosztas</a></li>
                    <li><a href="profil.php?aloldal=keszlet" >Készlet</a></li>
                    <li><a href="profil.php?aloldal=rendeles" >Rendelés</a></li>
                    <li><a href="profil.php?aloldal=penztar">Pénztár</a>
                    <li><a href="profil.php?aloldal=napileltar" >Napi leltár</a></li>
                    </li>
                </ul>
            </nav>
            <form action="kijelentkezes.php" method="post">
                    <input type="submit"  name="kijelent" value="Kijelentkezés">
                    </form>
            <div class="ham">
                        <div class="hambar1"></div>
                        <div class="hambar2"></div>
                        <div class="hambar3"></div>
            </div>
    
    </header>
    <article>
    <?php
    
			if(isset($_GET["aloldal"]))
            {
                $oldal=$_GET["aloldal"];
                $cel=$oldal.".php";
                if(file_exists($cel)) include($cel);
                else print ("A kért oldal nem található");
            }
            else
            {
                include("profil_start.php");
            }
		?>
    </article>
    <footer>
        Minden jog fenntartva Copyright &#169; 2024
    </footer>

    

</body>
</html>