
<h1>Üdvözöllek a <?php echo $db_nev ?> rendszerében!</h1>
