<?php
session_start();

// db_nev session változó be van-e állítva 
if(isset($_SESSION['db_nev'])) {
    $db_nev = $_SESSION['db_nev'];

    // Kapcsolódás az adatbázishoz
    $kapcsolat = mysqli_connect("localhost", "root", "", $db_nev);}

       if (isset($_POST['dolgozo'])){
         $sql="SELECT  nev FROM felhasznalok ORDER BY nev ASC;";
        $eredmeny=mysqli_query($kapcsolat,$sql);
        $db=mysqli_num_rows($eredmeny);
        if($db>0)
        {
            $vissza=array();
            while($sor=mysqli_fetch_array($eredmeny))
            {
                $temp=array();
                $temp['dolgozo']=$sor['nev'];
                
                $vissza[]=$temp;
            }
        }
        header('Content-Type:application/json');
        echo json_encode($vissza);
    }

if(isset($_POST['ev']))
    {
        $ev=$_POST['ev'];
        $sql="SELECT  felh_id, f_nev, nev, email, sz_hely, szul_ido FROM felhasznalok WHERE nev='$ev' ORDER BY felh_id ASC;";
      
        $eredmeny=mysqli_query($kapcsolat,$sql);
        $db=mysqli_num_rows($eredmeny);
        if($db>0)
        {
            $vissza=array();
            while($sor=mysqli_fetch_array($eredmeny))
            {
                $temp=array();
                $temp['felh_id'] = $sor['felh_id'];
                $temp['f_nev'] = $sor['f_nev'];
                $temp['nev'] = $sor['nev'];
                $temp['email'] = $sor['email'];
                $temp['sz_hely'] = $sor['sz_hely'];
                $temp['szul_ido'] = $sor['szul_ido'];
                $vissza[]=$temp;
            }
        }
        header('Content-Type:application/json');
        echo json_encode($vissza);
    }
    mysqli_close($kapcsolat);
?>
