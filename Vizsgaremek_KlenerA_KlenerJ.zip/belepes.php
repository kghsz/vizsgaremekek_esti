<h1>Belépés</h1>
<hr>
<?php
include "kozos.php";
	if(isset($_GET["hiba"]))
	{
		if($_GET["hiba"]==1)
		{
			?>
			<div class="hiba">Kérem töltse ki az űrlapot!</div>
			<?php
		}
		if($_GET["hiba"]==2)
		{
			?>
			<div class="hiba">Nem megfelelő útválasztó!</div>
			<?php
		}
	}
?>
<form method="post" action="login.php" enctype="multipart/form-data">
	<fieldset>
                    <input type="text" name="fnev" id="fnev" placeholder="Felhasználónév" required>
                    <br>
                    <input type="password" name="jelszo" id="password" placeholder="Jelszó" required>
                    <br>
					<Select id="utvalaszto" name="utvalaszto">
						<option>Válasszon</option>
						<option value="tulajdonos">Tulajdonos</option>
						<option value="dolgozo">Dolgozó</option>
					</Select>
					<input type="submit" name="submit" value="Belépés"><br>
	</fieldset>
</form>
