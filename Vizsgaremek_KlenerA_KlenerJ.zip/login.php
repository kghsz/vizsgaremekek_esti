<?php
session_start();
include "kozos.php";


if(isset($_POST["fnev"]) && isset($_POST["jelszo"]) && isset($_POST['utvalaszto'])) {
    $fnev = $_POST["fnev"];
    $jelszo = $_POST["jelszo"];
    $utvalaszto = $_POST['utvalaszto'];

    $fnev = mysqli_real_escape_string($kapcsolat, $fnev);
    $hashelt_jelszo = jelszo_hash($jelszo);

    if(empty($fnev) || empty($hashelt_jelszo)) {
        header("location: index.php?aloldal=belepes&hiba=1");
        exit;
    } else {
        $kapcsolat = mysqli_connect("localhost", "root", "", "onyx");
        if($kapcsolat === false) {
            die("Hiba: Nem sikerült kapcsolódni az adatbázishoz: " . mysqli_connect_error());
        }

        if($utvalaszto == "dolgozo") {
            $sql_felhasznalo = "SELECT db_nev FROM felhasznalok WHERE f_nev='$fnev' AND jelszo='$hashelt_jelszo';";
            $eredmeny_felhasznalo = mysqli_query($kapcsolat, $sql_felhasznalo);
            if($eredmeny_felhasznalo === false) {
                die("Hiba az adatbázis lekérdezés során: " . mysqli_error($kapcsolat));
            }

            $db = mysqli_num_rows($eredmeny_felhasznalo);
            if($db == 1) {
                $tabla = mysqli_fetch_array($eredmeny_felhasznalo);
                $db_nev = $tabla['db_nev'];

                if(!$kapcsolat->select_db($db_nev)) {
                    die("Hiba az adatbázis kiválasztásakor: " . $kapcsolat->error);
                } else {
                    $_SESSION['db_nev'] = $db_nev;
                    header("location: profil.php");
                    exit;
                }
            }
        } elseif($utvalaszto == "tulajdonos") {
            $sql_ceg = "SELECT db_nev FROM cegek WHERE ceg_nev='$fnev' AND jelszo='$hashelt_jelszo'";
            $eredmeny_ceg = mysqli_query($kapcsolat, $sql_ceg);
            if($eredmeny_ceg === false) {
                die("Hiba az adatbázis lekérdezés során: " . mysqli_error($kapcsolat));
            }

            $db = mysqli_num_rows($eredmeny_ceg);
            if($db == 1) {
                $tabla = mysqli_fetch_array($eredmeny_ceg);
                $db_nev = $tabla['db_nev'];

                if(!$kapcsolat->select_db($db_nev)) {
                    die("Hiba az adatbázis kiválasztásakor: " . $kapcsolat->error);
                } else {  
                    $_SESSION['db_nev']= $db_nev;
                    header("location: cegprofil.php");
                    exit;
                }
            }
        } else {
            echo "Kérem, válasszon típust!"; 
            header("refresh:3;url=index.php?aloldal=belepes"); // Visszanavigálás az index.php oldalra 3 másodperc után
            exit;
        }
    }
} else {
    echo "location: index.php?aloldal=belepes&hiba=2";
}
?>
