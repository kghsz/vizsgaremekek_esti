<?php
include "kozos.php";
session_start();



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    

    

    $ceg_nev = mysqli_real_escape_string($kapcsolat,$_POST["ceg_nev"]);
    $knev = mysqli_real_escape_string($kapcsolat, $_POST["knev"]);
    $tel = mysqli_real_escape_string($kapcsolat, $_POST["tel"]);
    $email = mysqli_real_escape_string($kapcsolat, $_POST["email"]);
    $jelszo = mysqli_real_escape_string($kapcsolat, $_POST["jelszo"]);
    $jelszo2 = mysqli_real_escape_string($kapcsolat, $_POST["jelszo2"]);
    $hashelt_jelszo = jelszo_hash($jelszo);

    if ($jelszo !== $jelszo2) {
        echo "A jelszavak nem egyeznek!";
    } else {
        // Adatbázis létrehozása a cégnév alapján
        $db_nev = str_replace(' ', '_', strtolower($ceg_nev));
        $sql_uj_adatbazis = "CREATE DATABASE IF NOT EXISTS $db_nev";
        
        // Adatbázis kapcsolódás
        $kapcsolat = new mysqli('localhost', 'root', '');

        // Ellenőrizze a kapcsolatot
        if ($kapcsolat->connect_error) {
            die("Kapcsolódási hiba: " . $kapcsolat->connect_error);
        }
        
        // Adatbázis létrehozása
        if ($kapcsolat->query($sql_uj_adatbazis) === TRUE) {
            // Új adatbázis kiválasztása
            $kapcsolat->select_db($db_nev);

            // SQL kérés az új adatbázis tábla létrehozására (cég adatok tábla)
            $sql_uj_tabla = "CREATE TABLE IF NOT EXISTS ceg_adatok (
                                    ceg_nev VARCHAR(100) NOT NULL,
                                    kapcs_nev VARCHAR(100) NOT NULL,
                                    kapcs_tel VARCHAR(20),
                                    email VARCHAR(50),
                                    jelszo VARCHAR(255) NOT NULL,
                                    db_nev VARCHAR(255)  NOT NULL
                                )";
            // SQL kérés az új adatbázis tábla létrehozására (felhasználók tábla)
            $sql_uj_tabla_felhasznalok = "CREATE TABLE IF NOT EXISTS felhasznalok (
                                    felh_id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                                    f_nev VARCHAR(255) NOT NULL,
                                    nev VARCHAR(255) NOT NULL,
                                    email VARCHAR(255) NOT NULL,
                                    sz_hely VARCHAR(255) NOT NULL,
                                    szul_ido DATE NOT NULL,
                                    jelszo VARCHAR(255) NOT NULL
                                )";

            // Új tábla létrehozása az új adatbázisban
            if ($kapcsolat->query($sql_uj_tabla) === TRUE) {
                // SQL kérés az új rekord hozzáadására az új adatbázis táblájához
                $sql_uj_adat = "INSERT INTO ceg_adatok (ceg_nev, kapcs_nev, kapcs_tel, email, jelszo, db_nev) 
                                      VALUES ('$ceg_nev', '$knev', '$tel', '$email', '$hashelt_jelszo','$db_nev')";

                // Új rekord hozzáadásának ellenőrzése
                if ($kapcsolat->query($sql_uj_adat) === TRUE) {
                    echo "Sikeres regisztráció és adatbázis létrehozás!";
                } else {
                    echo "A rekord hozzáadása nem sikerült: " . $kapcsolat->error;
                }
            } else {
                echo "A tábla létrehozása nem sikerült: " . $kapcsolat->error;
            }
            if ($kapcsolat->query($sql_uj_tabla_felhasznalok) === TRUE) {
                echo "A felhasználók tábla létrehozása sikeresen megtörtént, vagy már létezett!";
            } else {
                echo "A felhasználók tábla létrehozása nem sikerült: " . $kapcsolat->error;
            }
        } else {
            echo "Az adatbázis létrehozása nem sikerült: " . $kapcsolat->error;
        }
        // Adatbázis nevének tárolása a munkamenetben

        $kapcsolat->close();

        $kapcsolat=mysqli_connect("localhost","root","","onyx");
        // Külső adatbázis kapcsolódása
        $kapcsolat->select_db('onyx');

        // SQL kérés az új rekord hozzáadására a külső adatbázis táblájához
        $sql_uj_adat_kulsodb = "INSERT INTO cegek (ceg_nev, kapcs_nev, kapcs_tel, email, jelszo, db_nev) 
                                       VALUES ('$ceg_nev', '$knev', '$tel', '$email', '$hashelt_jelszo', '$db_nev')";


        // Külső adatbázisba történő új rekord hozzáadásának ellenőrzése
        if ($kapcsolat->query($sql_uj_adat_kulsodb) === TRUE) {
            // Az adatbázisba beszúrt cég azonosítójának lekérése
            $ceg_id = $kapcsolat->insert_id;

            // Session változók beállítása
            
            $_SESSION['db_nev'] = $db_nev;
            
            echo "Sikeres rekord hozzáadás a külső adatbázishoz!";
            header("Location: cegprofil.php");
            exit();
        } else {
            echo "A rekord hozzáadása a külső adatbázishoz nem sikerült: " . $kapcsolat->error;
           
        }
        
        $kapcsolat->close(); // Kapcsolat bezárása
    }

}
?>

<h1>Regisztráció</h1>
<hr>
<form action="#" method="post" enctype="multipart/form-data">
    <fieldset>
    <label for="ceg_nev">Cég név:</label>
    <input type="text" name="ceg_nev" id="ceg_nev" required>
    <br>
    <label for="knev">Kacspolat tartó neve:</label>
    <input type="text" name="knev" id="knev"  required>
    <br>
    <label for="tel">Kapcsolat tartó tel.:</tel></label>
    <input type="text" name="tel" id="tel"  required>
    <br>
    <label for="email">E-mail:</label>
    <input type="email" name="email" id="email" required>
    <br>
    <label for="pwd">Jelszó</label>
    <input type="password" name="jelszo" id="jelszo" required>
    <br>
    <label for="pwd2">Jelszó mégegyszer</label>
    <input type="password" name="jelszo2" id="jelszo2" required>
    <br>
    <input type="submit" name="submit" value="Regisztráció">
    </fieldset>
</form>
