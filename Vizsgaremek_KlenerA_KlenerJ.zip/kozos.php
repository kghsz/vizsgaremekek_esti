<?php

// Cégek azonosítói és azokhoz tartozó adatbázisok
global $kapcsolat;
$kapcsolat=mysqli_connect("localhost","root","","onyx");
mysqli_set_charset($kapcsolat,"utf8");
//kacspolat ellenőrzése
if ($kapcsolat->connect_error) {
    die("Sikertelen kapcsolódás: " . $kapcsolat->connect_error); // sikertelen kapcsolódás
  } 


// Globális só definíciója
if (!defined('GLOBAL_SALT')){
define('GLOBAL_SALT', 'Süt ránk a napsugár<>@');
}

if (!function_exists('jelszo_hash')) {
// Jelszó hash-elése
function jelszo_hash($jelszo) {
    $hashelt_jelszo = hash("sha256", GLOBAL_SALT . $jelszo);
    return $hashelt_jelszo;
}
}







?>

