<?php
include "kozos.php";  //behivjuk az kozop fügvényeket

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="design3.css">
    <title>Onyx Corporate Control</title>
    <script type="text/javascript">
		// kód helye
		$(document).ready(function(){
			$(".ham").click(function(){
				$(this).toggleClass("forgat");
				$("nav").toggleClass("csuszik");
			})
		})
	</script>
</head>
<body>
    <header>
        <div class="fejlec">
            <div class="logodiv">
                    <img src="home_logo.JPG" id="logo">
                    <a href="index.php" id="logo_sz">Onyx Corporate Control</a> 
            </div>
            <nav >   <!-- menü -->
                <ul>
                    <li><a href="index.php">Kezdőlap</a></li>
                    <li><a href="index.php?aloldal=kapcsolat">Kapcsolat</a></li>
					<li><a href="index.php?aloldal=belepes">Belépés</a></li>	
                    <li><a href="index.php?aloldal=cegreg">Regisztráció</a></li>
                </ul>
            </nav>
            <div class="ham">
				<div class="hambar1"></div>
				<div class="hambar2"></div>
				<div class="hambar3"></div>
			</div>
		</div>
    </header>
    <div class="bg"></div>
    <article>                   <!-- az aloldalak behivása-->
        <?php
			if(isset($_GET['aloldal']))
            {
                $oldal=$_GET["aloldal"];
                $cel=$oldal.".php";
                if(file_exists($cel)) include($cel);
                else print ("A kért oldal nem található");
            }
            else
            {
                include('start.php');
            }
		?>

    </article>
    <footer>
        Minden jog fenntartva Copyright &#169; 2024
    </footer>
        

    


   
</body>
</html>
