﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ConnectToMySQL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            try
            {
                    
                //string connstr= "server=mysql.nethely.hu:port:3306; uid=vizsgaremek;pwd=********;database=vizsgaremek";
                string connstr = "server=localhost; uid=root;pwd=;database=vizsgaremek";
                MySqlConnection kapcsolat = new MySqlConnection();
                kapcsolat.ConnectionString = connstr;
                kapcsolat.Open();
                if (kapcsolat.State == ConnectionState.Open)
                {
                    string sql = "SELECT felhasznalo_id,fnev,jelszo FROM felhasznalo;";
                    MySqlCommand cmd = new MySqlCommand(sql, kapcsolat);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        string sor = reader["felhasznalo_id"].ToString() + "\t" + reader["fnev"];
                        listBox1.Items.Add(sor);
                    }
                }
                else { MessageBox.Show("Nem sikerült kapcsolódni az adatbázishoz"); }
            }
            catch (MySqlException ex)
            {
                //MessageBox.Show(ex.ToString());
                MessageBox.Show("Kapcsolódási hiba: " + ex.Number + ", " + ex.Message);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string connstr = "server=mysql.nethely.hu; uid=vizsgaremek;pwd=*******;database=vizsgaremek";
            string connstr = "server=localhost; uid=root;pwd=;database=vizsgaremek";
            MySqlConnection kapcsolat = new MySqlConnection();
            kapcsolat.ConnectionString = connstr;
            kapcsolat.Open();
            string elem_id = listBox1.SelectedItem.ToString();
            int id = int.Parse(elem_id.Substring(0, elem_id.IndexOf('\t')));
            string sql = "DELETE FROM felhasznalo WHERE felhasznalo_id="+id+";";
            MySqlCommand cmd = new MySqlCommand(sql, kapcsolat);
            DialogResult eredmeny = MessageBox.Show("Véglegesen törli a felhasználót?", "Törlés", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            bool valasz = (eredmeny == DialogResult.Yes);
            if (valasz)
            {
                MySqlDataReader reader = cmd.ExecuteReader();
                button1_Click(sender, e);
               
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
