<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kattintható Kép</title>
    <link rel="stylesheet" href="./design.css">
</head>
<body>
<h1>Látnivalók a közelben</h1>
<hr>
    <div class="szovegek">
        <?php
        // Szövegek és képek tömbje
        $szovegek_es_kepek = array(
            array("szoveg" => "DEBRECEN: - Könnyű séta a debreceni Nagyerdőben. Felejthetetlen élményt nyújt a Debreceni Egyetem monumentális, klasszicista stílusban épült épülete és az előtte kialakított csodás franciapark. ", "kep" => "./latnivalok4/debrecen.jpg"),

            array("szoveg" => "A VIRÁGKARNEVÁL: Debrecen legnépszerűbb turisztikai eseménye. Gyökerei az 1910-es évekre nyúlnak     vissza, amikor a város főutcáján látványos virágkorzó vonzotta a látogatókat. 1966 óta minden év augusztus 20-án rendezik meg.", "kep" => "./latnivalok4/viragkarneval.jpg"),

            array("szoveg" => "HORTOBÁGY: - Az erre a vidékre látogató turistáknak rendkívüli élmény lehet világörökség részévé választott hortobágyi puszta. Ajánljuk az őshonos állatokkal és élőhelyeikkel, a pusztai élet sajátosságaival barátkozni kívánó vendégeinknek. Látványosság még a kilenclyukú híd.", "kep" => "./latnivalok4/hortobagy.jpg"),

            array("szoveg" => "TOKAJ: - Budapest után az egyik legismertebb magyar város, a történelmi borvidék fővárosa. Tokajban tett séta az itt található borospincékkel kezdődhet.", "kep" => "./latnivalok4/tokaj.jpg"),
        );

        // Szövegek és képek kiíratása oszlopokba
        foreach ($szovegek_es_kepek as $elem) {
            echo "<div class='column'>";
            echo "<p>{$elem['szoveg']}</p>";
            echo "<img src='{$elem['kep']}' alt='Képek' class='latnivalok_kepei'>";
            echo "</div>";
        }
        ?>
    </div>
    <script ></script>
</body>
</html>
