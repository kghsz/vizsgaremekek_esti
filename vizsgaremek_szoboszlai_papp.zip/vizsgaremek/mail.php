<?php

// PHPMailer osztályok importálása a globális névtérbe
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Szükséges fájlok
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Ellenőrizzük, hogy a "send" gomb meg lett-e nyomva
if (isset($_POST["send"])) {

  // Példányosítjuk a PHPMailer objektumot, és engedélyezzük a kivételeket
  $mail = new PHPMailer(true);

  // Szerver beállítások
  $mail->isSMTP();                        // SMTP használata
  $mail->Host       = 'smtp.gmail.com';   // SMTP szerver beállítása (pl. Gmail esetén)
  $mail->SMTPAuth   = true;               // SMTP hitelesítés engedélyezése
  $mail->Username   = 'szbattl@gmail.com';// SMTP email címem
  $mail->Password   = 'frpntekhjcsanesx'; // SMTP jelszavam
  $mail->SMTPSecure = 'ssl';              // Implicit SSL titkosítás engedélyezése
  $mail->Port       = 465;                // Port szám

  // Ellenőrizzük, hogy minden mező ki van-e töltve
  if (isset($_POST["name"], $_POST["email"], $_POST["subject"], $_POST["message"]) &&
      !empty($_POST["name"]) && !empty($_POST["email"]) && !empty($_POST["subject"]) && !empty($_POST["message"])) {

    // Címzettek beállítása
    $fromEmail = $_POST["email"];
    $fromName = $_POST["name"];
    $mail->setFrom(mb_encode_mimeheader($fromEmail, 'UTF-8', 'Q'), mb_encode_mimeheader($fromName, 'UTF-8', 'Q'));   // Küldő email és név
    $mail->addAddress('szbattl@gmail.com'); // Címzett email hozzáadása
    $mail->addReplyTo(mb_encode_mimeheader($fromEmail, 'UTF-8', 'Q'), mb_encode_mimeheader($fromName, 'UTF-8', 'Q'));  // Válaszlevél küldése a küldőnek

    // Email tartalmának beállítása
    $mail->isHTML(true);         // Email formátum beállítása HTML-re
    $mail->Subject = mb_encode_mimeheader($_POST["subject"], 'UTF-8', 'Q'); // Email tárgy
    $mail->Body = mb_convert_encoding($_POST["message"], 'UTF-8', 'auto'); // Email üzenet

    // Sikeres elküldött üzenet értesítés
    $mail->send();

    echo "
      <script> 
        alert('Üzenetét elküldtük, hamarosan válaszolunk!');
        history.back();
      </script>
    ";

  } else {
    // Ha valamelyik mező nincs kitöltve, akkor kiírjuk egy hibaüzenetet és visszalépünk az előző oldalra

    // Hiányzó mezők listája
    $missingFields = [];
    if (empty($_POST["name"])) {
      $missingFields[] = "Név";
    }
    if (empty($_POST["email"])) {
      $missingFields[] = "E-mail cím";
    }
    if (empty($_POST["subject"])) {
      $missingFields[] = "Tárgy";
    }
    if (empty($_POST["message"])) {
      $missingFields[] = "Üzenet";
    }

    // Hibás üzenet és visszalépés a kapcsolat.php oldalra
    $errorMessage = "Kérjük, töltse ki a következő mezőket: " . implode(", ", $missingFields);
    echo "
      <script> 
        alert('$errorMessage');
        history.back();
      </script>
    ";
  }
}
?>
