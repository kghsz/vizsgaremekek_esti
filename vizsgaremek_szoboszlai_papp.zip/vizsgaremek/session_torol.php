<?php
    session_start();
    unset($_SESSION["felhasznalo_id"]);
    header ("location:index.php")
?>