A vizsgaremek depo main ágában van a vizsgaremek applikációja.
A vizsgaremek depo master ágában van a c#-ban írt applikáció.
A vizsgaremek.sql-ben van az adatbázis export állománya.
A vizsgaremek_szoboszlai_papp.pdf-ben van a dokumentáció.

Szoboszlai Attila github azonosítója: Aquavital
Papp Lajos github azonosítója: coderlajos

Az applikáció "Adminisztrációs felület - Belépés" menüjébe a username és password: papplajos / Papplajos1@
