<body>
<h1 class="vvillog">Ez csak egy teszt oldal, nem fogadunk semmilyen foglalást!</h1>
<hr>
<br>
<div class="oszlopok">
<i>Az  Aqua - Vital Prémium  Apartman ***  modern épületegyüttesben helyezkedik el , <b>50 méterre  a Hungarospa Fürdőkomplexum Prémium Zónájától és kb. 5 perces sétára a Hungarospa  Fürdöbejárat 3-as kapujától</b> és 15 perces sétára az Aqua-Palace Élményfürdőtől. </i><br>
<br><i>A légkondicionált szálláshelyeink ,<b>ingyenes Wi-Fi hozzáféréssel, ingyenes zárt parkolási lehetőséggel </b>várják a pihenni és kikapcsolódni vágyó vendégeket. Az apartmanok fürdőszobával, Légkondicionálóval, teljesen felszerelt konyhával és műholdas sikképernyős televizióval rendelkeznek. A gyerekek a szálláshely közelében  elhelyezkedő játszótéren, és a csónakázó tó  parkjában  vezethetik le felesleges energiáikat.</i><br>
<br><i>Az apartmanok közvetlen közelében éttermek, élelmiszerboltok, ajándékboltok, pékségek, kávézók, szórakozási lehetőségek - és a fürdő bejáratánál bank automata- találhatóak. A pár perces sétára található buszvégállomás révén könnyen megközelíthető akár tömegközlekedéssel is.</i><br>
<br><i><b>Bababarát szállás:</b> igény esetén téritésmentesen utazóágy, etetőszék , babakád igénybe vehető. </i><br>
<br><i>A legközelebbi repülőtér (Debrecen 20 km)-re lévő  mely nemzetközi repülőtér.</i><br>
<br><i><b>Szolgáltatásaink:</b> Ingyenes wifi az apartmanban; Zárt parkoló; Felszerelt konyha, TV ; Törölköző- és ágyneműcsere; Légkondicionáló(felár ellenében!); Központi fűtés;</i>
</div>
</body>
