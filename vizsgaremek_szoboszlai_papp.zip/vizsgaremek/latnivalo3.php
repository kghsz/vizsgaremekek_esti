<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kattintható Kép</title>
    <link rel="stylesheet" href="./design.css">
</head>
<body>
<h1>Prémium Zóna</h1>
<hr>
    <div class="szovegek">
        <?php
        // Szövegek és képek tömbje
        $szovegek_es_kepek = array(
            array("szoveg" => "A Plitvice medencében hatalmas sziklás vízesésben gyönyörködhetünk, beépített masszázs elemek, pezsgőágyak segítik az ellazulást.", "kep" => "./latnivalok3/premiumzona_vizeses.jpg"),

            array("szoveg" => "A Tahiti medence hullámzó vizében csobbanhatunk, majd vízibárjában trópusi koktélokat kóstolhatunk.", "kep" => "./latnivalok3/premium zona_2.jpg"),

            array("szoveg" => "Az Amazonas medence emeletes jakuzzi  tölcséreiben megmártózva csodálatos panoráma tárul elénk. A jakuzzik alatt a sodrófolyó örvényebiben lubickolhatunk.  ", "kep" => "./latnivalok3/premium zona_1.jpg"),

            array("szoveg" => "A Prémium Zóna ötcsillagos minőségi igényeket elégít ki szemet gyönyörködtető, különleges látványelemeivel, egyedi víziélményekkel és kényelemi wellness szolgáltatásokkal.  ", "kep" => "./latnivalok3/premiumzona_4.jpg"),

            array("szoveg" => "Az ország legújabb, legattraktívabb szabadtéri wellness fürdője várja a vendégeket  a strandfürdő kiegészítő szolgáltatásaként.", "kep" => "./latnivalok3/premiumzona_3.jpg"),
             
        );

        // Szövegek és képek kiíratása oszlopokba
        foreach ($szovegek_es_kepek as $elem) {
            echo "<div class='column'>";
            echo "<p>{$elem['szoveg']}</p>";
            echo "<img src='{$elem['kep']}' alt='Képek' class='latnivalok_kepei'>";
            echo "</div>";
        }
        ?>
    </div>
    <script ></script>
</body>
</html>
