<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kattintható Kép</title>
    <link rel="stylesheet" href="./design.css">
</head>
<body>
<h1>Városunk</h1>
<hr>
    <div class="szovegek">
        <?php
        // Szövegek és képek tömbje
        $szovegek_es_kepek = array(
            array("szoveg" => "Bocskai István múzeum 
                            A múzeum központi épületében látható a Hajdúszoboszló története a kezdetektől napjainkig című várostörténeti gyűjtemény. A kiállítás legbecsesebb darabja az országosan is számon tartott Bocskai-zászló, amelyet a hagyomány szerint a fejedelem adományozott a hajdúvitézeknek.", "kep" => "./latnivalok1/muzeum.jpg"),
            array("szoveg" => "Bocskai-szobor
                            A tér közepén áll Bocskai István lovas szobra, Marton László alkotása. A műalkotás a fejedelem alakjának szokatlan megformálásával hívja fel magára a figyelmünket.", "kep" => "./latnivalok1/szobor.jpg"),
            array("szoveg" => "Gönczy Pál szobra
                            A templomkertben helyezték el 1910-ben Hajdúszoboszló nagy szülöttjének, a pedagógus Gönczy Pálnak (1817-1892) a mellszobrát, Somogyi Sándor alkotását..", "kep" => "./latnivalok1/mellszobor.jpg"),
            array("szoveg" => "Törülköző nő, szobor
                            A strand területén állították fel Pátzay Pál Törülköző nő című, másfélszeres életnagyságú bronzszobrát, amely a szigligeti alkotóházban lévő eredeti alkotás másodpéldánya.", "kep" => "./latnivalok1/torolkozono.jpg"),
            array("szoveg" => "I. világháborús emlékmű
                                A templomkertben helyezték el 1927-ben a város I. világháborús emlékművét, Somogyi Sándor alkotását.", "kep" => "./latnivalok1/elsovilaghaboru.jpg"),
             array("szoveg" => "II. világháborús emlékmű
                                A város főtéren állították fel a II. világháború hajdúszoboszlói áldozatainak emlékművét.", "kep" => "./latnivalok1/másodikvilaghaboru.jpg"),
        );

        // Szövegek és képek kiíratása oszlopokba
        foreach ($szovegek_es_kepek as $elem) {
            echo "<div class='column'>";
            echo "<p>{$elem['szoveg']}</p>";
            echo "<img src='{$elem['kep']}' alt='Kattintható Kép' class='latnivalok_kepei'>";
            echo "</div>";
        }
        ?>
    </div>
    <script ></script>
</body>
</html>
