<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Névnapkereső {vizsgaremek_new}</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="nevnap.css">
    <style>
        body{
            background-color: lightgray;
        }
        .nevnap_keret{
            border: 1px solid black;
            background-color: black;
            color: beige;
            margin: auto;
            height: 50px;
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            border-radius: 6px 6px 6px;
            box-shadow: beige 5px 5px;
        }
    </style>
    <script>
        $(document).ready(function(){
            $("#kiir").load("nevnap_kereso.php", function()
            {
                var kiir_szel=$("#kiir").width();
                var keret_szel=kiir_szel+50;
                $(".keret").width(keret_szel+"px");
            })
        });
        
    </script>
</head>
<body>
    <div class="nevnap_keret">
        <div id="kiir"></div>
    </div>
</body>
</html>