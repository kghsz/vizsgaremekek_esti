<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kattintható Kép</title>
    <link rel="stylesheet" href="./design.css">
</head>
<body>
<h1>Strand</h1>
<hr>
    <div class="szovegek">
        <?php
        // Szövegek és képek tömbje
        $szovegek_es_kepek = array(
            array("szoveg" => "A fürdőkomplexum közel 30 hektáros területén 15 medence kínál fürdőzési lehetőséget az ide látogatók számára. .", "kep" => "./latnivalok2/strand2.jpg"),


            array("szoveg" => "Mediterrán tengerpart
                 A strandfejlesztés során az egyik legnagyobb figyelmet érdemlő fejlesztés a Mediterrán tengerpart, mely Közép-Európa legnagyobb épített strandmedencéje. A mediterrán stílust idézi meg a homokos part, a kalózhajó, a világítótorony és a pálmafák.", "kep" => "./latnivalok2/strand1.jpg"),

            array("szoveg" => "Gyermekmedencék
                    Az úszómedence nemcsak az úszás kedvelőinek áll a rendelkezésére, hanem sportversenyek megrendezésére is alkalmas.  .", "kep" => "./latnivalok2/strand3.jpg"),
            array("szoveg" => "Sportcentrum
                A fürdő területén található sportcentrumban a vízi élmények mellett sport élményekkel is gazdagodhatnak a fürdőzők. A strandröplabda, a lábtenisz, a ping-pong, a strandfoci, és a tenisz is az aktív kínálat elemei. ", "kep" => "./latnivalok2/strand4.jpg"),
        );

        // Szövegek és képek kiíratása oszlopokba
        foreach ($szovegek_es_kepek as $elem) {
            echo "<div class='column'>";
            echo "<p>{$elem['szoveg']}</p>";
            echo "<img src='{$elem['kep']}' alt='Képek' class='latnivalok_kepei'>";
            echo "</div>";
        }
        ?>
    </div>
    <script ></script>
</body>
</html>
