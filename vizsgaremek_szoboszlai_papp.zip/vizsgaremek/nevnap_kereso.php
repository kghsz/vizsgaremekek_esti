
<?php
require_once 'kapcsolodas.php';
$ho=date("n");
$nap=date("j");

if($result=$db->query("SELECT nev1, nev2 FROM nevnap WHERE ho=$ho AND nap=$nap;"));
{
    
        while($row=$result->fetch_object())
        {
            if($row->nev1!="" & $row->nev2!="")     
            {
                echo "<b>Ma ".$row->nev1." és ".$row->nev2." névnapja van</b>";
            }
            else
            {
                echo "<b>Ma ".$row->nev1." névnapja van</b>";   
            }
        }
}
?>