<?php
session_start();
require_once 'kapcsolodas.php';

if(!$_SESSION['felhasznalo_id'])
{

    if(isset($_POST['fn']) && isset($_POST['pw']))  //usernév / password vizsgálat a 'vizsgaremek' / 'felhasznalo' táblában
    {
        $fn=$_POST['fn'];
        $pw=$_POST['pw'];
        $fn=trim(strip_tags(stripslashes($fn))); //nem biztonságos karakterek kivétele
        $pw=trim(strip_tags(stripslashes($pw)));
        if($result=$db->query("SELECT jelszo, felhasznalo_id FROM felhasznalo WHERE fnev='$fn';")) //jelszó és felhasznalo_id kinyerése az vizsgaremek db-ból
        {
            if($result->num_rows==1)
            {
                while($row=$result->fetch_object())
                {
                    $jelszo=$row->jelszo;               //$jelszo változóba a db-ből kapott jelszót
                    $felhasznaloid=$row->felhasznalo_id; //felhasznalo_id kinyerése a db-ból
                }
            }
        }
        if($h_jelszo=password_verify($pw,$jelszo))   //ha a hash-elt jelszó==a beírt jelszóval
        {
            $_SESSION['felhasznalo_id']=$felhasznaloid; //session glob. változó értéke = db felhasznalo_id-ja
            header ("location: index.php?aloldal=adminisztracio");   //átirányít az adminisztracio.php oldalra
           
        }
        else
        {
            header ("location: index.php?aloldal=admin_belep&hiba=1"); //rossz jelszó v. pw
        }
        
        // if($result=$db->query("SELECT * FROM felhasznalo WHERE fnev='$fn' and jelszo='$pw';")) //user / pw keresése a 'felhasznalo' táblában
        // {
        //     if($result->num_rows==1)
        //     {
        //         $row=$result->fetch_object();
        //         $_SESSION['felhasznalo_id']=$row->felhasznalo_id;     //a 'felhasznalo' -> felhasznalo_id a $_SESSION global valtozoban, aminek a kulcsa:'felhasznalo_id'
        //         header ("location: index.php?aloldal=adminisztracio"); //átirányít az adminnisztracio.php-be, ha OK a user/pw
        //     }
        //     else
        //     {
        //         header ("location: index.php?aloldal=admin_belep&hiba=1");  //ha nem jó, vissza az admin_belep.php-ba a hiba==1-gyel
        //     }
        // }
    }
}
else
{
    header ("location: index.php?aloldal=adminisztracio");
}
?>