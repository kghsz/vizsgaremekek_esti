<?php include_once("cookie.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="design2.css">
    <title>Kapcsolat</title>
</head>
<body>
    <header>
        <div class="fejlec">
            <div class="home">
                <a href="index.php"><img src="images/home.png" alt="Kezdőlap"></a>
            </div>
            <nav id="nav">
                    <a href="about.php">Rólunk</a>
                    <a href="termekek2.php">Termékek</a>
                    <a href="szolg.php">Szolgáltatások</a>
                    <a href="kapcsolat.php">Kapcsolat</a>
                    <div class="lenyilo">
                        <button class="lenyilo-btn">Bejelentkezés</button>
                        <div class="almenu">
                            <a href="belepes.php">Bejelentkezés</a>
                            <a href="register2.php">Regisztráció</a>
                        </div>
                    </div>
            </nav>
        </div>
    </header>
    <div class="main">
            <div class="contact">
                <h1>Elérhetőségeink</h1>
                <h3>Cím:</h3>
                <h4>Kinizsi u. 18. Hajdúszoboszló 4200</h4>
                <h3>Telefon:</h3>
                <h4>+36 50/116-2266</h4>
                <h3>E-mail:</h3>
                <h4>bbcsoki.szoboszlo@gmail.com</h4>
            </div>
            <div class="nyitva">
                <h1>Nyitvatartás</h1>
                <div class="nyitvatartas">
                    <div class="napok">
                        <h3>Hétfő:</h3>
                        <h3>Kedd:</h3>
                        <h3>Szerda:</h3>
                        <h3>Csütörtök:</h3>
                        <h3>Péntek:</h3>
                        <h3>Szombat:</h3>
                        <h3>Vasárnap:</h3>
                    </div>
                    <div class="nyitas">
                        <h3>9:00 - 15:00</h3>
                        <h3>ZÁRVA</h3>
                        <h3>9:00 - 15:00</h3>
                        <h3>9:00 - 15:00</h3>
                        <h3>9:00 - 15:00</h3>
                        <h3>ZÁRVA</h3>
                        <H3>ZÁRVA</H3>
                    </div>
                </div>
            </div>
    </div>
    <script>
        // Ellenőrizzük a bejelentkezési állapotot
        var bejelentkezve = <?php echo json_encode($bejelentkezve); ?>;

        $(document).ready(function() {
            // Ha a felhasználó be van jelentkezve, változtassuk meg a lenyilo osztályt
            if (bejelentkezve) {
                $(".lenyilo").html('<div class="lenyilo"><button class="lenyilo-btn" id="profnev"><img src="images/user.png" alt="userlogo" height="15px">Profil</button><div class="almenu"><a href="#">Profil</a><a href="logout.php">Kijelentkezés</a></div></div>');
            }
        });
    </script>
</body>
</html>