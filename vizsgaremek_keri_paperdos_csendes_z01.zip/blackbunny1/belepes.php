<?php include_once("cookie.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="design2.css">
    <title>Bejelentkezés</title>
</head>
<body>
    <header>
        <div class="fejlec">
            <div class="home">
                <a href="index.php"><img src="images/home.png" alt="Kezdőlap"></a>
            </div>
            <nav id="nav">
                    <a href="about.php">Rólunk</a>
                    <a href="termekek2.php">Termékek</a>
                    <a href="szolg.php">Szolgáltatások</a>
                    <a href="kapcsolat.php">Kapcsolat</a>
                    <div class="lenyilo">
                        <button class="lenyilo-btn active">Bejelentkezés</button>
                        <div class="almenu">
                            <a href="belepes.php">Bejelentkezés</a>
                            <a href="register2.php">Regisztráció</a>
                        </div>
                    </div>
            </nav>
        </div>
    </header>
    <div class="login">
        <form action="login.php" method="post">
            <label for="fnev">Fejlhasználónév:</label>
            <input type="text" name="fnev" id="fnev" required><br>
            <label for="jelszo">Jelszó:</label>
            <input type="password" name="jelszo" id="jelszo" required><br>
            <input type="submit" value="Bejelentkezés">
        </form>
        <a href="register2.php">Még nem regisztráltál? Itt megteheted!</a>
    </div>