<?php
// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve a cookie alapján
if(isset($_COOKIE['user_id'])) {
    // A felhasználó be van jelentkezve
    $bejelentkezve = true;
} else {
    // A felhasználó nincs bejelentkezve
    $bejelentkezve = false;
}
?>