<?php
// Adatbázis csatlakozás
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blackbunny3";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Sikertelen csatlakozás az adatbázishoz: " . $conn->connect_error);
}

// Termékek lekérdezése az adatbázisból
$sql = "SELECT nev, egysegar, kiszereles, termek_id, leiras FROM termekek";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Termékek megjelenítése
    while($row = $result->fetch_assoc()) {
        echo '<div class="termek">';
        echo '<img src="images/termekek/' . $row["termek_id"] . '.jpg" alt="' . $row["nev"] .'">';
        echo '<h2>' . $row["nev"] . '</h2>';
        echo '<p>' . $row["egysegar"] . ' Ft' . ' / ' . $row["kiszereles"] . '</p>';
        echo '<div id="kosar">';
        echo '<button class="kosarba" data-termekid="' . $row["termek_id"] .'">Kosárba rakom</button>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo "Nincs találat";
}
$conn->close();
?>