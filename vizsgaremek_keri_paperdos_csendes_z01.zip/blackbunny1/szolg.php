<?php include_once("cookie.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="design2.css">
    <title>Szolgáltatások</title>
</head>
<body>
    <header>
        <div class="fejlec">
            <div class="home">
                <a href="index.php"><img src="images/home.png" alt="Kezdőlap"></a>
            </div>
            <nav id="nav">
                    <a href="about.php">Rólunk</a>
                    <a href="termekek2.php">Termékek</a>
                    <a href="szolg.php">Szolgáltatások</a>
                    <a href="kapcsolat.php">Kapcsolat</a>
                    <div class="lenyilo">
                        <button class="lenyilo-btn">Bejelentkezés</button>
                        <div class="almenu">
                            <a href="belepes.php">Bejelentkezés</a>
                            <a href="register2.php">Regisztráció</a>
                        </div>
                    </div>

            </nav>
        </div>
    </header>
        <div class="szolg-main">
            <h1>Szolgáltatásaink</h1>
            <div class="szolgaltatas">
                <p>Egyedi Csokoládékészítés: Vásárlóink részére lehetőséget biztosítunk arra, hogy egyedi igények alapján rendeljenek személyre szabott csokoládékat. Lehet választani az ízek, formák és díszítések közül, hogy valóban egyedi ajándékot vagy különleges desszertet hozzanak létre.</p>
                <img src="images/szolg/egyedi.jpg" alt="Egyedi csokoládé készítése">
            </div>
            <div class="szolgaltatas">
                <p>Csokoládé Degusztációk: Szervezünk online vagy személyes csokoládé degusztációkat, ahol részletesen megismerhetik a különböző csokoládék fajtáit, ízeit és eredetét. Professzionális csokoládés szakértőink segítségével felfedezhetik a csokoládék világát, miközben élvezik a kóstolást.</p>
                <img src="images/szolg/degusz.jpg" alt="Degusztációs rendezvény">
            </div>
            <div class="szolgaltatas">
                <p>Csokoládé Szakmai Tanfolyamok: Csatlakozzanak szakmai tanfolyamainkhoz, ahol elsajátíthatják a csokoládékészítés fortélyait. Különféle kurzusokat kínálunk kezdőktől a haladó szintig, ahol betekintést nyerhetnek a csokoládéipar rejtelmeibe és megtanulhatják a legjobb technikákat és praktikákat.</p>
                <img src="images/szolg/kurzus.png" alt="Kurzus">
            </div>
            <div class="szolgaltatas">
                <p>Csokoládé Partik és Események: Szervezzünk egy felejthetetlen csokoládé parti vagy eseményt! Legyen szó születésnapról, lánybúcsúról vagy céges rendezvényről, mi biztosítjuk az élményt és az emlékezetes pillanatokat a résztvevőknek. A vendégek részvételével együtt készíthetünk csokoládét vagy akár csokoládé fondüzt is szervezhetünk.</p>               
                <img src="images/szolg/parti.png" alt="Parti">
            </div>
            <div class="szolgaltatas">
                <p>Ajándékcsomagok és Céges Megoldások: Különleges alkalomra keres ajándékot? Nézzen körül ajándékcsomagjaink között, melyek tartalmazzák a legfinomabb csokoládéinkat és egyéb kiegészítőket. Emellett vállaljuk céges megrendelések teljesítését is, például ünnepi ajándékok vagy céges események kiszolgálását egyedi csokoládé termékeinkkel.</p>
                <img src="images/szolg/ceges.png" alt="Céges csokikészítés">
            </div>
        </div>
    <script>
        // Ellenőrizzük a bejelentkezési állapotot
        var bejelentkezve = <?php echo json_encode($bejelentkezve); ?>;

        $(document).ready(function() {
            // Ha a felhasználó be van jelentkezve, változtassuk meg a lenyilo osztályt
            if (bejelentkezve) {
                $(".lenyilo").html('<div class="lenyilo"><button class="lenyilo-btn" id="profnev"><img src="images/user.png" alt="userlogo" height="15px">Profil</button><div class="almenu"><a href="#">Profil</a><a href="logout.php">Kijelentkezés</a></div></div>');
            }
        });
    </script>
</body>
</html>