<?php
include_once("cookie.php");
session_start();
// Adatbázis csatlakozás
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blackbunny3";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Sikertelen csatlakozás az adatbázishoz: " . $conn->connect_error);
}

// Ellenőrizd, hogy be van-e jelentkezve a felhasználó
if($bejelentkezve) {
    // Felhasználó be van jelentkezve, lehetőség van a kosárba rakásra
    if(isset($_POST['termekID']) && $_POST['termekID'] != "") {
        $termekID = $_POST['termekID'];
        
        // Felhasználó azonosítójának lekérése 
        if(isset($_COOKIE['user_id'])) {
            $userID = $_COOKIE['user_id'];
            
            // Beszúrás a kosár táblába
            $sql = "INSERT INTO kosar (termek_id, user_id) VALUES ('$termekID','$userID')
            ON DUPLICATE KEY UPDATE mennyiseg = mennyiseg + 1;";
            if ($conn->query($sql) === TRUE) {
                echo "A termék sikeresen hozzá lett adva a kosárhoz.";
            } else {
                echo "Hiba történt: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Nincs bejelentkezve felhasználó.";
        }
    } else {
        echo "Nincs termék azonosító.";
    }
} else {
    echo "Nincs bejelentkezve felhasználó.";
}

$conn->close();
?>
