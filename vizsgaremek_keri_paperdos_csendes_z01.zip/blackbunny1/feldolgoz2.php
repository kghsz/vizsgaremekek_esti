<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="blackbunny3";
$tableName="users";

$conn = new mysqli($servername, $username,$password,$dbname);

if ($conn->connect_error){
    die("Sikertelen kapcsolódás: ". $conn->connect_error);
}

function isValidPassword($password){
    return preg_match('/\d/', $password);
}

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $vnev=$_POST["vnev"];
    $knev=$_POST["knev"];
    $fnev=$_POST["fnev"];
    $jelszo=$_POST["jelszo"];
    $email=$_POST["email"];
    //$szul_dat=$_POST["szul_dat"];
    //$nem=$_POST["nem"];

    /*if (empty($vnev) || empty($knev) || empty($fnev) || empty($jelszo) || empty($email) || empty($szul_dat) || empty($nem)) {
        die("Minden mezőt ki kell tölteni.");
    }

    if(!isValidPassword($jelszo)){
        die("A jelszónak tartalmaznia kell legalább egy számot.");
    }*/

    $hash=password_hash($jelszo, PASSWORD_BCRYPT);

    $sql= "INSERT INTO users (vnev, knev, fnev, jelszo, email) VALUES ('$vnev', '$knev', '$fnev', '$hash', '$email')";

    if($conn->query($sql)===TRUE){
        echo "Sikeres regisztráció";
        header("Location: index.php");
        exit();
    }
    else{
        echo "Sikertelen regisztráció: " . $sql . "<br>" . $conn->error;
        header("Location: register2.php");
        exit();
    }

}

$conn->close();

?>