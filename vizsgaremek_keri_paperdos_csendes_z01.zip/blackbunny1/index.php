<?php include_once("cookie.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="design2.css">
    <title>Kezdőlap</title>
</head>
<body>
    <header>
        <div class="fejlec">
            <div class="home">
                <a href="index.php"><img src="images/home.png" alt="Kezdőlap"></a>
            </div>
            <nav id="nav">
                    <a href="about.php">Rólunk</a>
                    <a href="termekek2.php">Termékek</a>
                    <a href="szolg.php">Szolgáltatások</a>
                    <a href="kapcsolat.php">Kapcsolat</a>
                    <div class="lenyilo">
                        <button class="lenyilo-btn">Bejelentkezés</button>
                        <div class="almenu">
                            <a href="belepes.php">Bejelentkezés</a>
                            <a href="register2.php">Regisztráció</a>
                        </div>
                    </div>

            </nav>
        </div>
    </header>
    <div class="main">
        <div class="torzs">
            <div id="title"><p>Black <b>Bunny</b></p></div>
            <div id="alcim"><p>Prémium kézműves csokoládék és desszertek</p></div>
            <div id="gluten">
                <img src="images/gluten.png" alt="gluten">
                <p>Glutén-, laktózmentes és vegán csokoládék</p>
            </div>
        </div>
        <img id="logo" src="images/bkbunny.jpg" alt="logó">
    </div>
    <script>
        // Ellenőrizzük a bejelentkezési állapotot
        var bejelentkezve = <?php echo json_encode($bejelentkezve); ?>;

        $(document).ready(function() {
            // Ha a felhasználó be van jelentkezve, változtassuk meg a lenyilo osztályt
            if (bejelentkezve) {
                $(".lenyilo").html('<div class="lenyilo"><button class="lenyilo-btn" id="profnev"><img src="images/user.png" alt="userlogo" height="15px">Profil</button><div class="almenu"><a href="#">Profil</a><a href="logout.php">Kijelentkezés</a></div></div>');
            }
        });
    </script>
</body>
</html>