<?php include_once("cookie.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="design2.css">
    <title>Rólunk</title>
</head>
<body>
    <header>
        <div class="fejlec">
            <div class="home">
                <a href="index.php"><img src="images/home.png" alt="Kezdőlap"></a>
            </div>
            <nav id="nav">
                    <a href="about.php">Rólunk</a>
                    <a href="termekek2.php">Termékek</a>
                    <a href="szolg.php">Szolgáltatások</a>
                    <a href="kapcsolat.php">Kapcsolat</a>
                    <div class="lenyilo">
                        <button class="lenyilo-btn">Bejelentkezés</button>
                        <div class="almenu">
                            <a href="belepes.php">Bejelentkezés</a>
                            <a href="register2.php">Regisztráció</a>
                        </div>
                    </div>
            </nav>
        </div>
    </header>
    <div class="about-main">
        <h1>Rólunk</h1>
        <p>Családi vállalkozásunk, a BlackBunny célja, hogy minőségi, kézzel készített csokoládékat kínáljunk az édességkedvelőknek. A család minden tagja elkötelezett a kiváló minőségű alapanyagok és a hagyományos receptek felhasználása mellett, hogy olyan élményt nyújtsunk, amelyet másutt nem találnak. A vállalkozásunk létrehozásának fő indítéka az volt, hogy megőrizzük és továbbadjuk a családi recepteket és az édesanyánk által átadott kézműves csokoládékészítés tudását. Így célunk nem csupán az üzleti siker elérése, hanem a családi örökségünk ápolása és a finom csokoládé szeretetének megosztása az emberekkel, akik értékelik az igényességet és a hagyományok tiszteletét.</p>
        <div class="slidebox">
            <h3 class="slide-title">Termékfotók</h3>
            <div class="slide fade">
                <img src="images/slideshow/termekek/1.jpg" alt="termékfotó">
            </div>
            <div class="slide fade">
                <img src="images/slideshow/termekek/2.jpg" alt="termékfotó">
            </div>
            <div class="slide fade">
                <img src="images/slideshow/termekek/3.jpg" alt="termékfotó">
            </div>
            <div class="slide fade">
                <img src="images/slideshow/termekek/4.jpg" alt="termékfotó">
            </div>
            <a class="elozo" onclick="plusSlides(-1)">&#10094</a>
            <a class="kovetkezo" onclick="plusSlides(1)">&#10095</a>
        </div>
        <h3>Díjnyertes Kézműves Bonbonok</h3>
        <p>Kézműves bonbonjainkhoz valódi csokoládét, gyümölcsöket és dióféléket használunk fel. Csokoládéink termőhely szelektáltak, magas kakaótartalommal és 100%-os kakaóvajjal.</p>
        <img src="images/about/bonbon.jpg" alt="Bonbon">
        <p>Nem használunk aromát, színezéket és tartósítószereket sem. Az igazi ízélményt és az intenzív ízeket a természetes alapanyagok adják. Az elmúlt időszakban több rangos világversenyen is részt vettünk, melyeken arany, ezüst és bronzéremmel díjazták bonbonjainkat, csokoládéinkat.</p>
        <div class="slidebox">
            <h3 class="slide-title">Programok</h3>
            <div class="slide_p fade">
                <img src="images/slideshow/programok/1.jpg" alt="Programajánló">
            </div>
            <div class="slide_p fade">
                <img src="images/slideshow/programok/2.jpg" alt="Programajánló">
            </div>
            <div class="slide_p fade">
                <img src="images/slideshow/programok/3.jpg" alt="Programajánló">
            </div>
            <div class="slide_p fade">
                <img src="images/slideshow/programok/4.jpg" alt="Programajánló">
            </div>
            <a class="elozo" onclick="plusSlides_program(-1)">&#10094</a>
            <a class="kovetkezo" onclick="plusSlides_program(1)">&#10095</a>
        </div>
        <h3>Friss kézműves csokoládé</h3>
        <p>Mindig friss, mert így a legjobb! Ez neked is jár!</p>
        <img src="images/about/friss.jpg" alt="Csokitojás">
        <p>Finom, adalékmentes csokoládéink, mosolyt csalnak az arcokra. Az ajándék, ami nem a sokadik apróság lesz a polcon, nem kell aggódnod, hogy illik-e a megajándékozott otthonába. Ízlésesen csomagolt finomság, mely pillanatok alatt elfogy és örömet okoz.</p>
        <img src="images/about/ajandek.png" alt="Ajándék">
        <p>Az igazi ízélményt és az intenzív ízeket a természetes alapanyagok adják. Nem használunk olyan csokoládét, mely bármilyen tartósítószert vagy színezéket tartalmaz. Száműztük a különböző olcsó, kakaóvajat helyettesítő növényi olajokat, beleértve a pálmaolajat is. Ha szereted a természetes ízeket, a valódi gyümölcsöket és a frissen készült minőségi kézműves csokoládét, akkor kóstolj bele a BlackBunny csokoládék világába!</p>
    </div>
    <script>
            // Ellenőrizzük a bejelentkezési állapotot
            var bejelentkezve = <?php echo json_encode($bejelentkezve); ?>;

            $(document).ready(function() {
                // Ha a felhasználó be van jelentkezve, változtassuk meg a lenyilo osztályt
                if (bejelentkezve) {
                    $(".lenyilo").html('<div class="lenyilo"><button class="lenyilo-btn" id="profnev"><img src="images/user.png" alt="userlogo" height="15px">Profil</button><div class="almenu"><a href="#">Profil</a><a href="logout.php">Kijelentkezés</a></div></div>');
                }
            });
    </script>
    <script>
        let slideIndex=1;
        showSlides(slideIndex);

        let slideIndex_program=1;
        showSlides_program(slideIndex_program);

        function plusSlides(n){
            showSlides(slideIndex+=n);
        }y
        
        function plusSlides_program(m){
            showSlides_program(slideIndex_program+=m);
        }

        function showSlides(n){
            let i;
            let slides=document.getElementsByClassName("slide");
            if (n>slides.length) {slideIndex=1}
            if (n<1) {slideIndex=slides.length}
            for (i=0;i<slides.length;i++){
                slides[i].style.display="none";
            }
            slides[slideIndex-1].style.display="block";
            slides[slideIndex].className+=" active";
        }

        function showSlides_program(m){
            let i;
            let slides_p=document.getElementsByClassName("slide_p");
            if (m>slides_p.length) {slideIndex_program=1}
            if (m<1) {slideIndex_program=slides_p.length}
            for (i=0;i<slides_p.length;i++){
                slides_p[i].style.display="none";
            }
            slides_p[slideIndex_program-1].style.display="block";
            slides_p[slideIndex_program].className+=" active";
        }
    </script>
</body>
</html>