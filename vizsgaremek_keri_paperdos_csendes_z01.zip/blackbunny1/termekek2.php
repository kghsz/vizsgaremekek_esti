<!DOCTYPE html>
<?php include_once("cookie.php");?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="design2.css">
    <title>Termékeink</title>
</head>
<body>
    <header>
        <div class="fejlec">
            <div class="home">
                <a href="index.php"><img src="images/home.png" alt="Kezdőlap"></a>
            </div>
            <nav id="nav">
                    <a href="about.php">Rólunk</a>
                    <a href="termekek2.php">Termékek</a>
                    <a href="szolg.php">Szolgáltatások</a>
                    <a href="kapcsolat.php">Kapcsolat</a>
                        <div class="lenyilo">
                            <button class="lenyilo-btn">Bejelentkezés</button>
                            <div class="almenu">
                                <a href="belepes.php">Bejelentkezés</a>
                                <a href="register2.php">Regisztráció</a>
                            </div>
                        </div>
            </nav>
        </div>
    </header>
    <div class="main">
        <?php include_once("termeklista.php");?>

    </div>

    <script>
        $(document).ready(function() {
            $(".kosarba").click(function() {
                var termekID = $(this).data("termekid");
                $.ajax({
                    url: "kosarba.php", // Az a fájl, amely fogadja az adatokat
                    method: "POST",
                    data: { termekID: termekID },
                    success: function(response) {
                        console.error(response); 
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText); 
                    }
                });
            });
        });
    </script>
    <script>
        // Ellenőrizzük a bejelentkezési állapotot
        var bejelentkezve = <?php echo json_encode($bejelentkezve); ?>;

        $(document).ready(function() {
            // Ha a felhasználó be van jelentkezve, változtassuk meg a lenyilo osztályt
            if (bejelentkezve) {
                $(".lenyilo").html('<div class="lenyilo"><button class="lenyilo-btn" id="profnev"><img src="images/user.png" alt="userlogo" height="15px">Profil</button><div class="almenu"><a href="#">Profil</a><a href="logout.php">Kijelentkezés</a></div></div>');
            }
        });
    </script>
</body>
</html>