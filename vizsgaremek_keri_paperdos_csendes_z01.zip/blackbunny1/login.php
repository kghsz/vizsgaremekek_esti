<?php include_once("cookie.php");?>
<?php
$servername="localhost";
$username="root";
$password="";
$dbname="blackbunny3";
$tableName="users";

$conn=new mysqli($servername,$username,$password,$dbname);

if ($conn->connect_error){
    die("Sikertelen kapcsolódás: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"]=="POST"){
    $fnev=$_POST["fnev"];
    $jelszo=$_POST["jelszo"];

    $ellenorzes="SELECT * FROM users WHERE fnev = '$fnev'";
    $eredmeny= $conn->query($ellenorzes);

    if ($eredmeny->num_rows>0){
        $sor=$eredmeny->fetch_assoc();
        $titkos_jelszo=$sor["jelszo"];
    }

    if(password_verify($jelszo,$titkos_jelszo)){
        $user_id=$sor["user_id"];
        setcookie("user_id", $user_id, time()+(86400*30), "/");
        echo "Sikeres regisztráció";
        header("Location: index.php");
    } else{
        echo "Sikertelen bejelentkezés!<br><a href='belepes.php'>Visszatérés a bejelentkezéshez</a>";
    }
}

?>